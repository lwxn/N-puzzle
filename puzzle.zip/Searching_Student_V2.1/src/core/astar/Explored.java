package core.astar;

import core.problem.State;
import g11.problem.block.BlockState;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

//The set that remembers every expanded node
public class Explored {
    //Data Structures for Explored, implement it yourself.
    Set<Long>hashSet = new HashSet<>();
	private HashMap<Long, Node> maps = new HashMap<>();

	//插入一个节点
	public void insert(Node node){
		hashSet.add( ((BlockState)node.getState()).getZobrist());
		maps.put(((BlockState)node.getState()).getZobrist(),node);
	}
	
	public boolean contains(State state) {
		return hashSet.contains(((BlockState)state).getZobrist()); //Fix me
	}

	public Node revisited(State state) {
		return maps.get(((BlockState)state).getZobrist());
	}

}

