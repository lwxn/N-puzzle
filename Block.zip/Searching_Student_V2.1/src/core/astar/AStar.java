package core.astar;

import core.problem.Action;
import core.problem.Problem;
import core.problem.State;

import java.util.Stack;

public class AStar {
    public AStar(Problem problem) {
        super();
        this.problem = problem;
        this.startNode = null;
        this.endNode = null;
    }

    public Node childNode(Node parent, Action action) {
        State state = problem.result(parent.getState(), action);
        int pathCost = parent.getPathCost() + problem.stepCost(parent.getState(), action);
        int heuristic = problem.heuristic(state);
        return new Node(state, parent, action, pathCost, heuristic);
    }

    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }

    //��ͨ��astar
    public Node search1() {
        //��ʼ�ڵ�
        State initState = problem.getInitialState();
        Node node = new Node(initState, null, null, 0, problem.heuristic(initState));

        Fringe fringe = new Fringe();
        fringe.insert(node);

        Explored explored = new Explored();

        while (true) {

            node = fringe.pop();
            if (problem.goalTest(node.getState())) {
                return node;
            }
            explored.insert(node);
            for (Action action : problem.Actions(node.getState())) {
                Node child = childNode(node, action);
                if (!explored.contains(child.getState()) && !fringe.contains(child.getState())) {
                    fringe.insert(child);
                } else {
                    Node revisited = fringe.revisited(child.getState());
                    if (revisited != null && revisited.evaluation() > child.evaluation()) {
                        fringe.replace(revisited, child);
                    }
                }
            }
        }
    }

    //˫��BFS
    public Node search() {
        //��ʼ�ڵ�

        State initState = problem.getInitialState();
        State goalState = problem.getGoal();
        Node nodeInit = new Node(initState, null, null, 0, problem.heuristic(initState));
        Node nodeGoal = new Node(goalState, null, null, 0, problem.heuristic(goalState));

        //open1
        Fringe fringeInit = new Fringe();
        fringeInit.insert(nodeInit);

        //open2
        Fringe fringeGoal = new Fringe();
        fringeGoal.insert(nodeGoal);

        //close1
        Explored exploredInit = new Explored();

        //close2
        Explored exploredGoal = new Explored();

        while (true) {

            if (!fringeInit.isEmpty()) {
                nodeInit = fringeInit.pop();
                //�Ѿ��������?
                if (fringeGoal.contains(nodeInit.getState())) {
                    Node revis = fringeGoal.revisited(nodeInit.getState());

                    startNode = nodeInit;
                    endNode = revis;
                    startNode.draw();
                    endNode.draw();
                    nodeInit.setPathCost(startNode.getPathCost() + endNode.getPathCost());
                    return nodeInit;
                }
                exploredInit.insert(nodeInit);
                for (Action action : problem.Actions(nodeInit.getState())) {
                    Node child = childNode(nodeInit, action);
                    if (!exploredInit.contains(child.getState()) && !fringeInit.contains(child.getState())) {
                        fringeInit.insert(child);
                    } else {
                        Node revisited = fringeInit.revisited(child.getState());
                        if (revisited != null && revisited.evaluation() > child.evaluation()) {
                            fringeInit.replace(revisited, child);
                        }
                    }
                }
            }
            if (!fringeGoal.isEmpty()) {
                nodeGoal = fringeGoal.pop();
                //�Ѿ��������?
                if (fringeInit.contains(nodeGoal.getState())) {
                    Node  revis = fringeInit.revisited(nodeGoal.getState());
                    startNode = revis;
                    endNode = nodeGoal;
                    nodeGoal.setPathCost(startNode.getPathCost() + endNode.getPathCost());
                    return nodeGoal;
                }
                exploredGoal.insert(nodeGoal);
                for (Action action : problem.Actions(nodeGoal.getState())) {
                    Node child = childNode(nodeGoal, action);
                    if (!exploredGoal.contains(child.getState()) && !fringeGoal.contains(child.getState())) {
                        fringeGoal.insert(child);
                    } else {
                        Node revisited = fringeGoal.revisited(child.getState());
                        if (revisited != null && revisited.evaluation() > child.evaluation()) {
                            fringeGoal.replace(revisited, child);
                        }
                    }
                }
            } else if (fringeInit.isEmpty()) {
                return null;
            }
        }
    }


    //�ö���չʾ����Ľ�·��
    public void solution(Node node) {
        /// Fix me
        Stack<Node> s = new Stack<>();
        //node.draw();
        s.push(node);

        int result = 0;
        while (node.getParent() != null) {
            node = node.getParent();
            s.push(node);
            result++;
        }

        while (!s.empty()) {
            s.pop().draw();
        }
    }

    public int solution_zh(Node node) {
        /// Fix me
        Stack<Node> s = new Stack<>();
        //node.draw();
        s.push(node);

        int result = 0;
        while (node.getParent() != null) {
            node = node.getParent();
            s.push(node);
            result++;
        }

        while (!s.empty()) {
            s.pop().draw();
        }
        return result;
    }

    //��������
    public int solution_re(Node node) {
        /// Fix me
        Stack<Node> s = new Stack<>();
        node.draw();

        int result = 0;
        while (node.getParent() != null) {
            node = node.getParent();
            node.draw();
            result++;
        }

        while (!s.empty()) {
            s.pop().draw();
        }
        return result;
    }

    private Problem problem;
    private Node startNode;
    private Node endNode;
}
