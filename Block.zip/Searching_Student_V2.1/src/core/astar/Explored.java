package core.astar;

import core.problem.State;
import xu.problem.block.BlockState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;
import java.util.Set;

//The set that remembers every expanded node
public class Explored {
    //Data Structures for Explored, implement it yourself.
    Set<Long>hashSet = new HashSet<>();
	private HashMap<Long, Node> maps = new HashMap<>();


	public void insert(Node node){
		hashSet.add( ((BlockState)node.getState()).getZobrist());
		maps.put(((BlockState)node.getState()).getZobrist(),node);
		//Fix me
	}
	
	public boolean contains(State state) {
		return hashSet.contains(((BlockState)state).getZobrist()); //Fix me
	}

	public Node revisited(State state) {
		return maps.get(((BlockState)state).getZobrist());
	}

}

